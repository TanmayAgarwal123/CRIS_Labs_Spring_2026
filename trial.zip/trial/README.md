# analyze_books – packaged from notebook

Packaged from `/mnt/data/analyze_books.ipynb` into a runnable CLI script.

## Quickstart

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python analyze_books.py --help
```
